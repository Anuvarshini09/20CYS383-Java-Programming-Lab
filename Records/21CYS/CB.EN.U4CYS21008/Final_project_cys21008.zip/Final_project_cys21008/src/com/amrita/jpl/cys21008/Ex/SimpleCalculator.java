package com.amrita.jpl.cys21008.Ex;

/*@Author: Anuvarshini M K
 @Param : implementing simple calculator's functionality using Interfaces
 @return
 @version 0.5
 */

/*
 *An Interface named calculator is created
 *the CalculatorImpl class inherits the interface and overrides the functions of interface
 *the Main class is used to instantiate the class objects of CalculatorImpl
 */

import java.util.Scanner;


interface Calculator {
    double add(double num1, double num2);
    double subtract(double num1, double num2);
    double multiply(double num1, double num2);
    double divide(double num1, double num2);
}


class CalculatorImpl implements Calculator {

    public double add(double num1, double num2) {
        return num1 + num2;
    }


    public double subtract(double num1, double num2) {
        return num1 - num2;
    }


    public double multiply(double num1, double num2) {
        return num1 * num2;
    }

    public double divide(double num1, double num2) {
        if (num2 == 0) {
            throw new IllegalArgumentException("Cannot divide by zero!");
        }
        return num1 / num2;
    }
}

// Main class to execute the calculator
public class SimpleCalculator {
    public static void main(String[] args) {
        // Create an instance of the CalculatorImpl class
        Calculator calculator = new CalculatorImpl();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the first number: ");
        double num1 = scanner.nextDouble();
        System.out.print("Enter the second number: ");
        double num2 = scanner.nextDouble();
        double sum = calculator.add(num1, num2);
        double difference = calculator.subtract(num1, num2);
        double product = calculator.multiply(num1, num2);
        double quotient = calculator.divide(num1, num2);
        System.out.println("Sum: " + sum);
        System.out.println("Difference: " + difference);
        System.out.println("Product: " + product);
        System.out.println("Quotient: " + quotient);
    }
}
