package com.anuvarshini.amrita;//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Scanner;

public class TCPClient {
    public TCPClient() {
    }

    public static void main(String[] args) {
        try {
            Socket clientSocket = new Socket("localhost", 4424);
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter message to server: ");
            String request = sc.nextLine();
            outToServer.writeBytes(request + "\n");
            System.out.println("Sent to server: " + request);
            String response = inFromServer.readLine();
            System.out.println("Received from server: " + response);
            clientSocket.close();
        } catch (IOException var7) {
            var7.printStackTrace();
        }

    }
}