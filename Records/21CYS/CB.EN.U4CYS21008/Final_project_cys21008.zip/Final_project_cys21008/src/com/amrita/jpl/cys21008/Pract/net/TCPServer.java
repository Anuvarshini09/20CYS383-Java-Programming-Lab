package com.amrita.jpl.cys21008.Pract.net;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

/*@Author: Anuvarshini M K
 @Param : implementing TCP server using Java
 @return
 @version 0.5
 */

/*
 * TCP server's functionality is implemented in this code
 */

public class TCPServer {
    public TCPServer() {
    }

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(4424);
            System.out.println("Server started. Waiting for clients...");
            Socket clientSocket = serverSocket.accept();

            String clientRequest;
            do {
                System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                DataOutputStream outToClient = new DataOutputStream(clientSocket.getOutputStream());
                clientRequest = inFromClient.readLine();
                System.out.println("Received from client: " + clientRequest);
                String response = processRequest(clientRequest);
                outToClient.writeBytes(response + "\n");
                System.out.println("Sent to client: " + response);
            } while(clientRequest != "exit");

            clientSocket.close();
        } catch (IOException var7) {
            var7.printStackTrace();
        }

    }

    private static String processRequest(String request) {
        return "Server response: " + request.toUpperCase();
    }
}
