package com.amrita.jpl.cys21008.P2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * The QuizGame class is an abstract class representing a quiz game.
 * @Author:Anuvarshini M K
 */
abstract class QuizGame {

    /**
     * Starts the game.
     */
    void startGame() {
        System.out.println("[Abstract]: the game has started");
    }

    /**
     * Asks a question in the game.
     */
    public abstract void askQuestion();

    /**
     * Evaluates the answer to a question in the game.
     *
     * @param answer the answer to evaluate
     */
    public abstract void evaluateAnswer(String answer);
}

/**
 * The QuizGameListener interface defines methods for handling events related to a quiz game.
 */
interface QuizGameListener {

    /**
     * Called when a question is asked.
     *
     * @param question the question asked
     */
    public void onQuestionAsked(String question);

    /**
     * Called when an answer is evaluated.
     *
     * @param isCorrect true if the answer is correct, false otherwise
     */
    public void onAnswerEvaluated(boolean isCorrect);
}

/**
 * The QuizGameServer class represents a quiz game server.
 */
class QuizGameServer extends QuizGame implements QuizGameListener {

    int choice;
    QuizGameServer ob = new QuizGameServer();
    Socket s; // Declare s as an instance variable
    DataOutputStream dos;
    DataInputStream dis;

    /**
     * Starts the game on the server.
     */
    public void startGame() {
        System.out.println("The game has started");
        try {
            ServerSocket ss = new ServerSocket(2244);
            s = ss.accept(); // Assign the accepted socket to the instance variable s
            dos = new DataOutputStream(s.getOutputStream());
            dis = new DataInputStream(s.getInputStream());

            ob.askQuestion();
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }

    /**
     * Asks a question to the client.
     */
    public void askQuestion() {
        try {
            dos.writeUTF("Enter the choice");
            choice = Integer.parseInt(dis.readUTF());
            String question = null;
            if (choice == 1) {
                question = "How many fingers do you have";
            } else if (choice == 2) {
                question = "Which place is the capital of Tamil Nadu?";
            } else if (choice == 3) {
                question = "What is 2 + 3 ?";
            } else {
                dos.writeUTF("Enter a valid choice");
            }
            if (question != null) {
                ob.onQuestionAsked(question);
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }

    /**
     * Evaluates the answer provided by the client.
     *
     * @param answer the answer to evaluate
     */
    public void evaluateAnswer(String answer) {
        try {
            String answer1 = dis.readUTF();

            if (choice == 1 && answer.equals("10")) {
                ob.onAnswerEvaluated(true);
            } else if (choice == 2 && answer.equals("Chennai")) {
                ob.onAnswerEvaluated(true);
            } else if (choice == 3 && answer.equals("5")) {
                ob.onAnswerEvaluated(true);
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }

    /**
     * Handles the event when a question is asked.
     *
     * @param question the question asked
     */
    @Override
    public void onQuestionAsked(String question) {
        try {
            dos.writeUTF(question);
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }

    /**
     * Handles the event when an answer is evaluated.
     *
     * @param isCorrect true if the answer is correct, false otherwise
     */
    @Override
    public void onAnswerEvaluated(boolean isCorrect) {
        // Implementation
    }
}

/**
 * The Server class is the entry point for the quiz game server.
 */
public class Server {

    /**
     * The main method to start the quiz game server.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        QuizGameServer server = new QuizGameServer();
        server.startGame();
    }
}


