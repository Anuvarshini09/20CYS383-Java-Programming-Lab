package com.amrita.jpl.cys21008.Ex;

/*@Author: Anuvarshini M K
 @Param : implementing vehicle functionality using inheritance
 @return
 @version 0.5
 */

/*
*This code is an example of the functionality of Inheritance
*A Vehicle class is inherited by two classes named Car and Bike
*the Main class is used to instantiate the class objects
*/


import java.util.Scanner;

class Vehicle {
    boolean run_status = false;

    public void start() {
        System.out.println("started");
    }

    public void stop() {
        System.out.println("stopped");
    }
}

class Car extends Vehicle {
    Scanner sc = new Scanner(System.in);
    String model_Name;
    int year;
    int num_of_wheels;

    public Car() {
        model_Name = sc.nextLine();
        year = sc.nextInt();
        num_of_wheels = sc.nextInt();
        System.out.println("Car Instantiated with Parameters: " + model_Name + " " + year + " " + num_of_wheels);
    }

    public void drive(int gear) {
        System.out.println("Driving the car in gear position: " + gear);
    }
}

class Bike extends Vehicle {
    Scanner sc = new Scanner(System.in);
    String brand_Name;
    int year;
    int num_of_gears;

    public Bike() {
        brand_Name = sc.nextLine();
        year = sc.nextInt();
        num_of_gears = sc.nextInt();
        System.out.println("Bike Instantiated with Parameters: " + brand_Name + " " + year + " " + num_of_gears);
    }

    public void pedal(int speed) {
        System.out.println("Pedaling the bike at speed: " + speed);
    }
}

public class Inheritance {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int gear = sc.nextInt();
        int speed = sc.nextInt();
        Car c = new Car();
        c.start();
        c.drive(gear);
        c.stop();

        Bike b = new Bike();
        b.start();
        b.pedal(speed);
        b.stop();
    }
}
