package com.amrita.jpl.cys21008.endsem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class FileManagementSystemUI extends JFrame {
    private DefaultTableModel tableModel;
    private JTable table;
    private JButton addButton;
    private JButton deleteButton;
    private JButton refreshButton;

    private List<Document> document;
    private List<Image> image;
    private List<Video> video;

    public FileManagementSystemUI() {
        document = new ArrayList<>();
        image = new ArrayList<>();
        video = new ArrayList<>();

        setTitle("21UCYS End Semester Assignment com.amrita.jpl.cys21008.endsem.File Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 300);
        setLocationRelativeTo(null);

        addButton = new JButton("Add");
        deleteButton = new JButton("Delete");
        refreshButton = new JButton("Edit");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        getContentPane().add(buttonPanel, BorderLayout.NORTH);


        tableModel = new DefaultTableModel(new Object[]{"com.amrita.jpl.cys21008.endsem.File Name", "com.amrita.jpl.cys21008.endsem.File Size", "com.amrita.jpl.cys21008.endsem.File Type"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

    }
}






        abstract class File {
            String fileName;
            int fileSize;


            public abstract String getFileName();

            public abstract int getFileSize();

            public abstract void setFileName();

            public abstract void setFilesize();

            public abstract void displayFileDetails();
        }

        class Document extends File {
            String documentType;

            public Document(String fileName, int fileSize, String documentType) {
                this.fileName = fileName;
                this.fileSize = fileSize;
                this.documentType = documentType;
            }

            public String getFileName() {
                return fileName;
            }

            public int getFileSize() {
                return fileSize;
            }

            public void setFileName() {
                this.fileName = fileName;
            }

            public void setFilesize() {
                this.fileSize = fileSize;
            }

            public String getDocumentType() {
                return documentType;
            }

            public void setDocumentType() {
                this.documentType = documentType;
            }

            public void displayFileDetails() {
                getFileName();
                getFileSize();
                getDocumentType();
            }


        }

        class Image extends File {
            String resolution;

            public Image(String fileName, int fileSize, String resolution) {
                this.fileName = fileName;
                this.fileSize = fileSize;
                this.resolution = resolution;
            }

            public String getFileName() {
                return fileName;
            }

            public int getFileSize() {
                return fileSize;
            }

            public void setFileName() {
                this.fileName = fileName;
            }

            public void setFilesize() {
                this.fileSize = fileSize;
            }

            public String getResolution() {
                return resolution;
            }

            public void setResolution() {
                this.resolution = resolution;
            }

            public void displayFileDetails() {
                getFileName();
                getFileSize();
                getResolution();
            }
        }
        class Video extends File {
            String duration;

            public Video(String fileName, int fileSize, String duration) {
                this.fileName = fileName;
                this.fileSize = fileSize;
                this.duration = duration;
            }

            public String getFileName() {
                return fileName;
            }

            public int getFileSize() {
                return fileSize;
            }

            public void setFileName() {
                this.fileName = fileName;
            }

            public void setFilesize() {
                this.fileSize = fileSize;
            }

            public String getDuration() {
                return duration;
            }

            public void setDuration() {
                this.duration = duration;
            }

            public void displayFileDetails() {
                getFileName();
                getFileSize();
                getDuration();
            }

        }





