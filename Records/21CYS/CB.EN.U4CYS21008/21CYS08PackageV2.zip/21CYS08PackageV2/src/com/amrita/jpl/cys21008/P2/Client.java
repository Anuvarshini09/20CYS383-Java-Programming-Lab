package com.amrita.jpl.cys21008.P2;

/*
 This is a Client side machine
 It answers the questions asked by server

@author: Anuvarshini M K
 */



class QuizGameClient extends QuizGame implements QuizGameListener {
    void startGame(){}

    public void askQuestion(){
    }

    public void evaluateAnswer(String answer){}

    @Override
    public void onQuestionAsked(String question) {

    }

    @Override
    public void onAnswerEvaluated(boolean isCorrect) {

    }
}


public class Client {
    public static void main(String args[]){



    }
}
