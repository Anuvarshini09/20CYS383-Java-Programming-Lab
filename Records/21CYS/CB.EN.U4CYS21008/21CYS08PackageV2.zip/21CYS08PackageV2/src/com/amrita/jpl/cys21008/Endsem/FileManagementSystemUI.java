package com.amrita.jpl.cys21008.Endsem;



import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * A class representing a File Management System user interface.
 * @Author:Anuvarshini M K
 */
public class FileManagementSystemUI extends JFrame {
    private DefaultTableModel tableModel;
    private JTable table;
    private JButton addButton;
    private JButton deleteButton;
    private JButton refreshButton;

    private List<Document> document;
    private List<Image> image;
    private List<Video> video;

    /**
     * Constructs a new FileManagementSystemUI object.
     */
    public FileManagementSystemUI() {
        document = new ArrayList<>();
        image = new ArrayList<>();
        video = new ArrayList<>();

        setTitle("21UCYS End Semester Assignment File Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 300);
        setLocationRelativeTo(null);

        addButton = new JButton("Add");
        deleteButton = new JButton("Delete");
        refreshButton = new JButton("Edit");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        getContentPane().add(buttonPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"File Name", "File Size", "File Type"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }
}

/**
 * An abstract class representing a File.
 */
abstract class File {
    String fileName;
    int fileSize;

    /**
     * Returns the file name.
     *
     * @return the file name
     */
    public abstract String getFileName();

    /**
     * Returns the file size.
     *
     * @return the file size
     */
    public abstract int getFileSize();

    /**
     * Sets the file name.
     *
     * @param fileName the file name to set
     */
    public abstract void setFileName(String fileName);

    /**
     * Sets the file size.
     *
     * @param fileSize the file size to set
     */
    public abstract void setFileSize(int fileSize);

    /**
     * Displays the file details.
     */
    public abstract void displayFileDetails();
}

/**
 * A class representing a Document file.
 */
class Document extends File {
    String documentType;

    /**
     * Constructs a new Document object.
     *
     * @param fileName     the file name
     * @param fileSize     the file size
     * @param documentType the document type
     */
    public Document(String fileName, int fileSize, String documentType) {
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.documentType = documentType;
    }

    /**
     * Returns the file name.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Returns the file size.
     *
     * @return the file size
     */
    public int getFileSize() {
        return fileSize;
    }

    /**
     * Sets the file name.
     *
     * @param fileName the file name to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Sets the file size.
     *
     * @param fileSize the file size to set
     */
    public void setFileSize(int fileSize) {
        this.fileSize = fileSize;
    }

    /**
     * Returns the document type.
     *
     * @return the document type
     */
    public String getDocumentType() {
        return documentType;
    }

    /**
     * Sets the document type.
     *
     * @param documentType the document type to set
     */
    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    /**
     * Displays the file details.
     */
    public void displayFileDetails() {
        System.out.println("File Name: " + getFileName());
        System.out.println("File Size: " + getFileSize());
        System.out.println("Document Type: " + getDocumentType());
    }
}

/**
 * A class representing an Image file.
 */
class Image extends File {
    String resolution;

    /**
     * Constructs a new Image object.
     *
     * @param fileName   the file name
     * @param fileSize   the file size
     * @param resolution the image resolution
     */
    public Image(String fileName, int fileSize, String resolution) {
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.resolution = resolution;
    }

    /**
     * Returns the file name.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Returns the file size.
     *
     * @return the file size
     */
    public int getFileSize() {
        return fileSize;
    }

    /**
     * Sets the file name.
     *
     * @param fileName the file name to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Sets the file size.
     *
     * @param fileSize the file size to set
     */
    public void setFileSize(int fileSize) {
        this.fileSize = fileSize;
    }

    /**
     * Returns the image resolution.
     *
     * @return the image resolution
     */
    public String getResolution() {
        return resolution;
    }

    /**
     * Sets the image resolution.
     *
     * @param resolution the image resolution to set
     */
    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    /**
     * Displays the file details.
     */
    public void displayFileDetails() {
        System.out.println("File Name: " + getFileName());
        System.out.println("File Size: " + getFileSize());
        System.out.println("Resolution: " + getResolution());
    }
}


/**
 * A class representing a Video file.
 */


    class Video extends File {
        /**
         * Constructs a new Video object.
         *
         * @param fileName the file name
         * @param fileSize the file size
         * @param duration the video duration
         */

        String duration;

        /**
         * Constructs a new Video object.
         *
         * @param fileName the file name
         * @param fileSize the file size
         * @param duration the video duration
         */
        public Video(String fileName, int fileSize, String duration) {
            this.fileName = fileName;
            this.fileSize = fileSize;
            this.duration = duration;
        }

        /**
         * Returns the file name.
         *
         * @return the file name
         */
        public String getFileName() {
            return fileName;
        }

        /**
         * Returns the file size.
         *
         * @return the file size
         */
        public int getFileSize() {
            return fileSize;
        }

        /**
         * Sets the file name.
         *
         * @param fileName the file name to set
         */
        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        /**
         * Sets the file size.
         *
         * @param fileSize the file size to set
         */
        public void setFileSize(int fileSize) {
            this.fileSize = fileSize;
        }

        /**
         * Returns the video duration.
         *
         * @return the video duration
         */
        public String getDuration() {
            return duration;
        }

        /**
         * Sets the video duration.
         *
         * @param duration the video duration to set
         */
        public void setDuration(String duration) {
            this.duration = duration;
        }

        /**
         * Displays the file details.
         */
        public void displayFileDetails() {
            System.out.println("File Name: " + getFileName());
            System.out.println("File Size: " + getFileSize());
            System.out.println("Duration: " + getDuration());
        }
    }

