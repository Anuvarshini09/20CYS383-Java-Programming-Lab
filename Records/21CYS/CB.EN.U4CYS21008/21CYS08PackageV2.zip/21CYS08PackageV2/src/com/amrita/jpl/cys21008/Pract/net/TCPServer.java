package com.amrita.jpl.cys21008.Pract.net;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;



/**
 * The TCPServer class represents a TCP server that listens for client connections, processes client requests,
 * and sends responses back to the clients.
 * @Author:Anuvarshini M K
 */
public class TCPServer {

    /**
     * Constructs a TCPServer object.
     */
    public TCPServer() {
    }

    /**
     * The main method to create and run the TCP server.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        try {
            // Create a server socket and start listening for client connections
            ServerSocket serverSocket = new ServerSocket(4424);
            System.out.println("Server started. Waiting for clients...");

            // Accept client connection
            Socket clientSocket = serverSocket.accept();

            String clientRequest;
            do {
                // Print client information
                System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());

                // Set up input and output streams
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                DataOutputStream outToClient = new DataOutputStream(clientSocket.getOutputStream());

                // Read client request
                clientRequest = inFromClient.readLine();
                System.out.println("Received from client: " + clientRequest);

                // Process client request
                String response = processRequest(clientRequest);

                // Send response to the client
                outToClient.writeBytes(response + "\n");
                System.out.println("Sent to client: " + response);
            } while (!clientRequest.equals("exit"));

            // Close the client socket connection
            clientSocket.close();
        } catch (IOException var7) {
            var7.printStackTrace();
        }
    }

    /**
     * Processes the client request and generates a response.
     *
     * @param request the client request
     * @return the server response
     */
    private static String processRequest(String request) {
        return "Server response: " + request.toUpperCase();
    }
}







