package com.amrita.jpl.cys21008.Pract.net;



import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Scanner;

/**
 * The TCPClient class represents a TCP client that sends a message to a server and receives a response.
 * @Author:Anuvarshini M K
 */
public class TCPClient {

    /**
     * Constructs a TCPClient object.
     */
    public TCPClient() {
    }

    /**
     * The main method to create and run the TCP client.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        try {
            // Create a socket connection to the server
            Socket clientSocket = new Socket("localhost", 4424);

            // Set up input and output streams
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());

            // Read user input
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter message to server: ");
            String request = sc.nextLine();

            // Send the request to the server
            outToServer.writeBytes(request + "\n");
            System.out.println("Sent to server: " + request);

            // Receive the response from the server
            String response = inFromServer.readLine();
            System.out.println("Received from server: " + response);

            // Close the socket connection
            clientSocket.close();
        } catch (IOException var7) {
            var7.printStackTrace();
        }
    }
}
